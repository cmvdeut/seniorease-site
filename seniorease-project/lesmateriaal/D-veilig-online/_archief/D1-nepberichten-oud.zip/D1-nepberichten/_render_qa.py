#!/usr/bin/env python3
"""Render D1 print + beamer pages for visual QA."""
from pathlib import Path
import fitz

root = Path(__file__).resolve().parent
out = root / "_qa_pages"
out.mkdir(exist_ok=True)

# Clear old
for p in out.glob("*.png"):
    p.unlink()

print_pdf = root / "pdf" / "SeniorEase-D1-Verdacht-Bericht-v2.pdf"
beamer_pdf = root / "beamer" / "SeniorEase-D1-Beamer-v2.pdf"

doc = fitz.open(print_pdf)
print(f"Print pages: {len(doc)}")
for i, page in enumerate(doc):
    pix = page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5))
    pix.save(out / f"print-{i+1:02d}.png")
    # emptiness heuristic
    text = page.get_text("text").strip()
    print(f"  print {i+1}: {len(text)} chars, y-ish height used via blocks={len(page.get_text('blocks'))}")
doc.close()

doc = fitz.open(beamer_pdf)
print(f"Beamer pages: {len(doc)}")
for i, page in enumerate(doc):
    pix = page.get_pixmap(matrix=fitz.Matrix(1.4, 1.4))
    pix.save(out / f"beamer-{i+1:02d}.png")
    text = page.get_text("text").strip()
    print(f"  beamer {i+1}: {len(text)} chars")
doc.close()
print(f"QA pages in {out}")
