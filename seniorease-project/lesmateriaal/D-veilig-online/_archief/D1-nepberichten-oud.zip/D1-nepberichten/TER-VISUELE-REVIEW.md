# D1 PRODUCTIE V2.0 — TER VISUELE REVIEW

**Status:** klaar voor menselijke visuele review — **niet** zelf goedgekeurd.  
**Datum correctie:** 2026-09-07 (leesbaarheid + eindmissiedia)  
**Bron:** `docs/superpowers/specs/2026-09-07-d1-verdacht-bericht-inhoud-v2.md` 🔒  

## Deze correctieronde

1. **Print-PDF:** grotere tekst/regelafstand in draaiboek en hulp; START HIER één A4; scanbare Zegt/Toont/…-blokken; geen inhoud geschrapt.  
2. **Eindmissie-beamer:** één dia met bericht C + open opdracht (geen 7-stappenlijst).  

## Bestanden

| Onderdeel | Locatie |
|-----------|---------|
| Print | `pdf/SeniorEase-D1-Verdacht-Bericht-v2.pdf` |
| Beamer | `beamer/SeniorEase-D1-Beamer-v2.pdf` |
| ZIP | `../SeniorEase-D1-Verdacht-Bericht-v2-TER-VISUELE-REVIEW.zip` |

## Niet gedaan

- Geen inhoudelijk herontwerp · D2–D4 niet gestart · A/B/C niet gewijzigd · geen zelf-goedkeuring
